package com.example.cinema;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Cinema1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
